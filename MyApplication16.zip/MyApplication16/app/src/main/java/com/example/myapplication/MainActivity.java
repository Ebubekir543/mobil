package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edt;
    EditText sifre;
    Button btn;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button);
        edt=findViewById(R.id.editTextText);
        sifre=findViewById(R.id.editTextText2);
        txt=findViewById(R.id.textView);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void KontolEt(View view)
    {
        try {
            int sayi=Integer.parseInt(edt.getText().toString());
            if (sayi>100)
            {
                txt.setText("Hatalı giriş");
                Toast.makeText(this, "hatalı giriş", Toast.LENGTH_SHORT).show();
            }
            else{
                txt.setText("doğru");
                Toast.makeText(this, "doğru", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception ex)
        {
            txt.setText("Sayı gir");
            Toast.makeText(this, "Sayı giriniz", Toast.LENGTH_SHORT).show();
        }

    }

    public  void kont(View view){

        String isim =edt.getText().toString();
        String ed =sifre.getText().toString();
        if (isim.equals("admin")){
            txt.setText("GUGUGAGA");
            Toast.makeText(this, "GUGUGAGA", Toast.LENGTH_SHORT).show();

        }
        else
        {

            txt.setText("I HATE NİGGERS");
            Toast.makeText(this, "I HATE NİGGERS", Toast.LENGTH_SHORT).show();

        }







    }

    public  void sifret(View view) {

        String isim = edt.getText().toString();
        String ed = sifre.getText().toString();
        if (isim.equals("admin")&ed.equals("sifre")) {
            txt.setText("başarılı");
            Toast.makeText(this, "başarılı", Toast.LENGTH_SHORT).show();

        }  else {

            txt.setText("başarısız");
            Toast.makeText(this, "başarısız", Toast.LENGTH_SHORT).show();

        }


    }



}


