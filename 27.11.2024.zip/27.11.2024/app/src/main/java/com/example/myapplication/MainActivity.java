package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edt;
    EditText sifre;
    Button btn;
    EditText not;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button);
        edt=findViewById(R.id.editTextText);
        sifre=findViewById(R.id.editTextText2);
        not=findViewById(R.id.editTextText3);100
        txt=findViewById(R.id.textView);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void KontolEt(View view)
    {
        try {
            int sayi=Integer.parseInt(edt.getText().toString());
            if (sayi>100)
            {
                txt.setText("Hatalı giriş");
                Toast.makeText(this, "hatalı giriş", Toast.LENGTH_SHORT).show();
            }
            else{
                txt.setText("doğru");
                Toast.makeText(this, "doğru", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception ex)
        {
            txt.setText("Sayı gir");
            Toast.makeText(this, "Sayı giriniz", Toast.LENGTH_SHORT).show();
        }

    }

    public  void kont(View view){

        String isim =edt.getText().toString();
        String ed =sifre.getText().toString();
        if (isim.equals("admin")){
            txt.setText("GUGUGAGA");
            Toast.makeText(this, "GUGUGAGA", Toast.LENGTH_SHORT).show();

        }
        else
        {

            txt.setText("I HATE NİGGERS");
            Toast.makeText(this, "I HATE NİGGERS", Toast.LENGTH_SHORT).show();

        }







    }

    public  void sifret(View view) {

        String isim = edt.getText().toString();
        String ed = sifre.getText().toString();
        if (isim.equals("admin")&ed.equals("sifre")) {
            txt.setText("başarılı");
            Toast.makeText(this, "başarılı", Toast.LENGTH_SHORT).show();

        }  else {

            txt.setText("başarısız");
            Toast.makeText(this, "başarısız", Toast.LENGTH_SHORT).show();

        }


    }

    public  void notk(View view) {

        String isim = edt.getText().toString();
        String ed = sifre.getText().toString();
        String nott= not.getText().toString();
       int not1 = Integer.parseInt(edt.getText().toString());
        int not2 = Integer.parseInt(sifre.getText().toString());
        int not3 = Integer.parseInt(not.getText().toString());
       double sonuc = (not1+not2+not3)/3;
       if (sonuc<25){

           txt.setText("kaldı ort 1");
           Toast.makeText(this, "kaldı ort 1", Toast.LENGTH_SHORT).show();

       } else if (sonuc<50) {
           txt.setText("kaldı ort 2");
           Toast.makeText(this, "kaldı ort 2", Toast.LENGTH_SHORT).show();

       }
       else if (sonuc<70) {
           txt.setText("geçti ort 3");
           Toast.makeText(this, "geçti ort 3", Toast.LENGTH_SHORT).show();

       }
       else if (sonuc<85) {
           txt.setText("geçti ort 4");
           Toast.makeText(this, "geçti ort 4", Toast.LENGTH_SHORT).show();

       }
       else if (sonuc<100) {
           txt.setText("geçti ort 5");
           Toast.makeText(this, "geçti ort 5", Toast.LENGTH_SHORT).show();

       }
    }



}


